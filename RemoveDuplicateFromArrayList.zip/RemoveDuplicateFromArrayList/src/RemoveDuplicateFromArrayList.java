
import java.util.ArrayList;
import java.util.Arrays;

public class RemoveDuplicateFromArrayList {

    public static <a> ArrayList<a> removeDuplicates(ArrayList<a> list)
    {
        ArrayList<a> newList = new ArrayList<a>();
        for (a element : list) {
            if (!newList.contains(element)) {
                newList.add(element);
            }
        }
  
        return newList;
    }
  
    public static void main(String args[])
    {
        ArrayList<Integer>
            list = new ArrayList<>(Arrays.asList(4,3,4,7,3,7,4,4));
        System.out.println("ArrayList with duplicates: " + list);
        ArrayList<Integer>
            newList = removeDuplicates(list);
        System.out.println("ArrayList without duplicates: " + newList);          
    }
}
