

	import java.util.Scanner;

	public class Calculator {

		public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			
			System.out.print("Enter the first value= ");
			String input1=sc.nextLine();
			double d1=Double.parseDouble(input1);
			
			System.out.print("Enter the second value= ");
			String input2=sc.nextLine();
			double d2=Double.parseDouble(input2);
			
			System.out.print("Enter the Operation you want to perform(+,-,*,/): ");
			String input3=sc.nextLine();
			
			double result=0;
			
			switch (input3) {
			case "+":
				result=(d1+d2);
				break;
				
			case "-":
				result=(d1-d2);
				break;
				
			case "*":
				result=(d1*d2);
				break;
				
			case "/":
				result=(d1/d2);
				break;
			
			default:
				System.out.println("Enter a correct operation "+input3);
				return;
			}
			System.out.println("The answer is: " + result);	
	}
	}


