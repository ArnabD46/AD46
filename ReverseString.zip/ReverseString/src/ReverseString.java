
import java.util.Scanner;

public class ReverseString {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the string you want to reverse= ");
		String st=sc.nextLine();
		char ch[]=st.toCharArray();
		String rev="";
		for (int i = ch.length-1; i>=0; i--) {
			rev+= ch[i];
		}
		System.out.println("The reversed string is: "+rev);
	}
}
