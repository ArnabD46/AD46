
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class GettingKeyValuePair {
	public static void main(String[] args) {
		Map<String, Integer> map=new HashMap<>();
		map.put("Ram", 17);
		map.put("Rajesh", 37);
		map.put("Anisha", 20);
		map.put("Kailash", 33);
		for(Entry<String, Integer> pair: map.entrySet()) {
			System.out.println(String.format("key is: %s, value is:%s",pair.getKey(),pair.getValue()));
		}
	}
}
