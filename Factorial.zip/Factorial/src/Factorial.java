
import java.util.Scanner;

public class Factorial {

	public static void main(String[] args) {
		int n,var=1;
		Scanner s=new Scanner(System.in);
		System.out.print("Enter the integer: ");
		n= s.nextInt();
		for (int i = 1; i <=n; i++) {
			var=var*i;
			
		}
		System.out.println("Factorial of "+n+" is: "+var);
			
		}
}
