
public class MethodOverRiding {
	class Forces{  
		public void run(){
			  System.out.println("Forces are the pride of acountry");
			  }  
		 }  
	class Navy extends Forces{  
	public static void main(String args[]){   
    Navy nav = new Navy(); 
		  nav.run();  
	  }  
	}  
}



