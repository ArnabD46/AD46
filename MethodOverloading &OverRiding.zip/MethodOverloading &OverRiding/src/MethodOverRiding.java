	class Forces{  
		public void run(){
			  System.out.println("Forces are the pride of a country");
			  }  
		 }  
	class Navy extends Forces{ 
	    public void run() {
		      System.out.println("Navy rules the seas");
	          }  
	     }  
	public class MethodOverRiding {
		public void main(String[] args) {
			Forces forces =new Forces(); 
			forces.run();
			
			Forces forces1=new Navy(); 
			forces1.run();
		}
}





