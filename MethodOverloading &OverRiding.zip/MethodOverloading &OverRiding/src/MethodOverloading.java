
class multiplier{
static double mul(int a, int b) {return a*b;}
static double mul(int a, int b, int c) {return a*b*c;}
}
public class MethodOverloading {
	public static void main(String[] args) {
		System.out.println(multiplier.mul(16, 24));
		System.out.println(multiplier.mul(16, 24, 36));
	}

}
