
class addition{
	public static int sum(int a, int b) {
		return a+b;
	}
}
 class StaticMethodAndCalling {

	public static void main(String[] args) {
	       int a=4,b=6;
	       int res=addition.sum(a, b);
	       System.out.println("the sum is: "+res);
	}
}