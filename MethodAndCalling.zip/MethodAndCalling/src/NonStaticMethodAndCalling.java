
class subtract{
	public int sub(int a,int b) {
		return a-b;
	}
}
class NonStaticMethodAndCalling {

	public static void main(String[] args) {
		int a=11,b=9;
		subtract sub=new subtract();
		int res=sub.sub(a,b);
		System.out.println("The answer is: "+res);
	}
}