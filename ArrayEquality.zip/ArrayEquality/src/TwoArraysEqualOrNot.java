
import java.util.Scanner;
public class TwoArraysEqualOrNot {

	public static void main(String[] args) {
		int n,k;
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the number of eliments for the 1st array: ");
		n=sc.nextInt();
		int a[] =new int[n];
		System.out.print("Enter the eliments for Array 1: ");
		for (int i = 0; i <n; i++) {
			a[i]=sc.nextInt();
		}
		System.out.print("Enter the number of eliments for the 2nd array: ");
		k=sc.nextInt();
		int b[] =new int[k];
		System.out.print("Enter the eliments for Array 2: ");
		for (int i = 0; i <k; i++) {
			b[i]=sc.nextInt();
	    }
		boolean res=true;
		if (a.length == b.length) {
			for (int i = 0; i < a.length; i=i+1) {
				if (a[i]!=b[i]) {
					res=false;
				}
			}
		}
		else {
			res=false;
		}
		if(res==true) {
			System.out.println("Arrays are equal");
		}
		else {
			System.out.println("Arrays are not equal");
		}

}
}
