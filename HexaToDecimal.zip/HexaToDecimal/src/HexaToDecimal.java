import java.util.Scanner;

public class HexaToDecimal {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the HexaDecimal value= ");
		String hex=sc.nextLine();
		int decimal=Integer.parseInt(hex,16);
		System.out.println(decimal);
	}

}
